package br.com.sgv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgvApplicationTests {

	@Test
	void contextLoads() {
	}

}
