/**
 * Author:  Pablo Rangel <pablo.rangel@gmail.com>
 * Created: 2 de jul de 2021
 */
insert into Usuario (login,senha, papel, id) values
('admin','$2a$10$K6PG.YUsSpMT/LOyPpeB5eUVdPImfDfSH.N0xLHAC1NbgbIBhraHe','ADMIN',1);
